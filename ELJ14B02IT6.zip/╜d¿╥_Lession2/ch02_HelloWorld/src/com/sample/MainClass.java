/*
 * 檔名：MainClass.java
 * 用途：認識 Java 程式結構
 */
package com.sample;

import java.lang.*;

//主類別
public class MainClass {

    /**
     * 主方法，程式進入點 *
     */
    public static void main(String[] args) {
        System.out.println("Hello!World!");
    }
}
